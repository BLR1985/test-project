import { defineConfig, passthroughImageService} from "astro/config";
import icon from "astro-icon";

export default defineConfig({
  image: {
    service: passthroughImageService()
  },
  integrations: [
    icon({
      iconDir: "src/icons",
    })
  ]
});