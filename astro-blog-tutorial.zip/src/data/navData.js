const navData = [
    {
      name: "О нас",
      path: "/about/",
    },
    {
      name: "Статьи",
      path: "/blog/",
    },
  ]
  
  export default navData;